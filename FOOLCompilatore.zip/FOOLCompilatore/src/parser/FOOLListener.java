// Generated from /Users/chiaraminervino/Desktop/FOOLCompilatore/src/parser/FOOL.g4 by ANTLR 4.8
package parser;


import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link FOOLParser}.
 */
public interface FOOLListener extends ParseTreeListener {
    /**
     * Enter a parse tree produced by {@link FOOLParser#prog}.
     * @param ctx the parse tree
     */
    void enterProg(FOOLParser.ProgContext ctx);
    /**
     * Exit a parse tree produced by {@link FOOLParser#prog}.
     * @param ctx the parse tree
     */
    void exitProg(FOOLParser.ProgContext ctx);
    /**
     * Enter a parse tree produced by the {@code letInStms}
     * labeled alternative in {@link FOOLParser#block}.
     * @param ctx the parse tree
     */
    void enterLetInStms(FOOLParser.LetInStmsContext ctx);
    /**
     * Exit a parse tree produced by the {@code letInStms}
     * labeled alternative in {@link FOOLParser#block}.
     * @param ctx the parse tree
     */
    void exitLetInStms(FOOLParser.LetInStmsContext ctx);
    /**
     * Enter a parse tree produced by the {@code classDecBlock}
     * labeled alternative in {@link FOOLParser#block}.
     * @param ctx the parse tree
     */
    void enterClassDecBlock(FOOLParser.ClassDecBlockContext ctx);
    /**
     * Exit a parse tree produced by the {@code classDecBlock}
     * labeled alternative in {@link FOOLParser#block}.
     * @param ctx the parse tree
     */
    void exitClassDecBlock(FOOLParser.ClassDecBlockContext ctx);
    /**
     * Enter a parse tree produced by {@link FOOLParser#classdec}.
     * @param ctx the parse tree
     */
    void enterClassdec(FOOLParser.ClassdecContext ctx);
    /**
     * Exit a parse tree produced by {@link FOOLParser#classdec}.
     * @param ctx the parse tree
     */
    void exitClassdec(FOOLParser.ClassdecContext ctx);
    /**
     * Enter a parse tree produced by {@link FOOLParser#let}.
     * @param ctx the parse tree
     */
    void enterLet(FOOLParser.LetContext ctx);
    /**
     * Exit a parse tree produced by {@link FOOLParser#let}.
     * @param ctx the parse tree
     */
    void exitLet(FOOLParser.LetContext ctx);
    /**
     * Enter a parse tree produced by {@link FOOLParser#vardec}.
     * @param ctx the parse tree
     */
    void enterVardec(FOOLParser.VardecContext ctx);
    /**
     * Exit a parse tree produced by {@link FOOLParser#vardec}.
     * @param ctx the parse tree
     */
    void exitVardec(FOOLParser.VardecContext ctx);
    /**
     * Enter a parse tree produced by {@link FOOLParser#varasm}.
     * @param ctx the parse tree
     */
    void enterVarasm(FOOLParser.VarasmContext ctx);
    /**
     * Exit a parse tree produced by {@link FOOLParser#varasm}.
     * @param ctx the parse tree
     */
    void exitVarasm(FOOLParser.VarasmContext ctx);
    /**
     * Enter a parse tree produced by {@link FOOLParser#fundec}.
     * @param ctx the parse tree
     */
    void enterFundec(FOOLParser.FundecContext ctx);
    /**
     * Exit a parse tree produced by {@link FOOLParser#fundec}.
     * @param ctx the parse tree
     */
    void exitFundec(FOOLParser.FundecContext ctx);
    /**
     * Enter a parse tree produced by the {@code varDecAssignment}
     * labeled alternative in {@link FOOLParser#dec}.
     * @param ctx the parse tree
     */
    void enterVarDecAssignment(FOOLParser.VarDecAssignmentContext ctx);
    /**
     * Exit a parse tree produced by the {@code varDecAssignment}
     * labeled alternative in {@link FOOLParser#dec}.
     * @param ctx the parse tree
     */
    void exitVarDecAssignment(FOOLParser.VarDecAssignmentContext ctx);
    /**
     * Enter a parse tree produced by the {@code funDeclaration}
     * labeled alternative in {@link FOOLParser#dec}.
     * @param ctx the parse tree
     */
    void enterFunDeclaration(FOOLParser.FunDeclarationContext ctx);
    /**
     * Exit a parse tree produced by the {@code funDeclaration}
     * labeled alternative in {@link FOOLParser#dec}.
     * @param ctx the parse tree
     */
    void exitFunDeclaration(FOOLParser.FunDeclarationContext ctx);
    /**
     * Enter a parse tree produced by {@link FOOLParser#type}.
     * @param ctx the parse tree
     */
    void enterType(FOOLParser.TypeContext ctx);
    /**
     * Exit a parse tree produced by {@link FOOLParser#type}.
     * @param ctx the parse tree
     */
    void exitType(FOOLParser.TypeContext ctx);
    /**
     * Enter a parse tree produced by {@link FOOLParser#exp}.
     * @param ctx the parse tree
     */
    void enterExp(FOOLParser.ExpContext ctx);
    /**
     * Exit a parse tree produced by {@link FOOLParser#exp}.
     * @param ctx the parse tree
     */
    void exitExp(FOOLParser.ExpContext ctx);
    /**
     * Enter a parse tree produced by {@link FOOLParser#operand}.
     * @param ctx the parse tree
     */
    void enterOperand(FOOLParser.OperandContext ctx);
    /**
     * Exit a parse tree produced by {@link FOOLParser#operand}.
     * @param ctx the parse tree
     */
    void exitOperand(FOOLParser.OperandContext ctx);
    /**
     * Enter a parse tree produced by {@link FOOLParser#term}.
     * @param ctx the parse tree
     */
    void enterTerm(FOOLParser.TermContext ctx);
    /**
     * Exit a parse tree produced by {@link FOOLParser#term}.
     * @param ctx the parse tree
     */
    void exitTerm(FOOLParser.TermContext ctx);
    /**
     * Enter a parse tree produced by {@link FOOLParser#factor}.
     * @param ctx the parse tree
     */
    void enterFactor(FOOLParser.FactorContext ctx);
    /**
     * Exit a parse tree produced by {@link FOOLParser#factor}.
     * @param ctx the parse tree
     */
    void exitFactor(FOOLParser.FactorContext ctx);
    /**
     * Enter a parse tree produced by {@link FOOLParser#atom}.
     * @param ctx the parse tree
     */
    void enterAtom(FOOLParser.AtomContext ctx);
    /**
     * Exit a parse tree produced by {@link FOOLParser#atom}.
     * @param ctx the parse tree
     */
    void exitAtom(FOOLParser.AtomContext ctx);
    /**
     * Enter a parse tree produced by the {@code intVal}
     * labeled alternative in {@link FOOLParser#value}.
     * @param ctx the parse tree
     */
    void enterIntVal(FOOLParser.IntValContext ctx);
    /**
     * Exit a parse tree produced by the {@code intVal}
     * labeled alternative in {@link FOOLParser#value}.
     * @param ctx the parse tree
     */
    void exitIntVal(FOOLParser.IntValContext ctx);
    /**
     * Enter a parse tree produced by the {@code boolVal}
     * labeled alternative in {@link FOOLParser#value}.
     * @param ctx the parse tree
     */
    void enterBoolVal(FOOLParser.BoolValContext ctx);
    /**
     * Exit a parse tree produced by the {@code boolVal}
     * labeled alternative in {@link FOOLParser#value}.
     * @param ctx the parse tree
     */
    void exitBoolVal(FOOLParser.BoolValContext ctx);
    /**
     * Enter a parse tree produced by the {@code nullVal}
     * labeled alternative in {@link FOOLParser#value}.
     * @param ctx the parse tree
     */
    void enterNullVal(FOOLParser.NullValContext ctx);
    /**
     * Exit a parse tree produced by the {@code nullVal}
     * labeled alternative in {@link FOOLParser#value}.
     * @param ctx the parse tree
     */
    void exitNullVal(FOOLParser.NullValContext ctx);
    /**
     * Enter a parse tree produced by the {@code baseExp}
     * labeled alternative in {@link FOOLParser#value}.
     * @param ctx the parse tree
     */
    void enterBaseExp(FOOLParser.BaseExpContext ctx);
    /**
     * Exit a parse tree produced by the {@code baseExp}
     * labeled alternative in {@link FOOLParser#value}.
     * @param ctx the parse tree
     */
    void exitBaseExp(FOOLParser.BaseExpContext ctx);
    /**
     * Enter a parse tree produced by the {@code ifExp}
     * labeled alternative in {@link FOOLParser#value}.
     * @param ctx the parse tree
     */
    void enterIfExp(FOOLParser.IfExpContext ctx);
    /**
     * Exit a parse tree produced by the {@code ifExp}
     * labeled alternative in {@link FOOLParser#value}.
     * @param ctx the parse tree
     */
    void exitIfExp(FOOLParser.IfExpContext ctx);
    /**
     * Enter a parse tree produced by the {@code varExp}
     * labeled alternative in {@link FOOLParser#value}.
     * @param ctx the parse tree
     */
    void enterVarExp(FOOLParser.VarExpContext ctx);
    /**
     * Exit a parse tree produced by the {@code varExp}
     * labeled alternative in {@link FOOLParser#value}.
     * @param ctx the parse tree
     */
    void exitVarExp(FOOLParser.VarExpContext ctx);
    /**
     * Enter a parse tree produced by the {@code funExp}
     * labeled alternative in {@link FOOLParser#value}.
     * @param ctx the parse tree
     */
    void enterFunExp(FOOLParser.FunExpContext ctx);
    /**
     * Exit a parse tree produced by the {@code funExp}
     * labeled alternative in {@link FOOLParser#value}.
     * @param ctx the parse tree
     */
    void exitFunExp(FOOLParser.FunExpContext ctx);
    /**
     * Enter a parse tree produced by the {@code methodExp}
     * labeled alternative in {@link FOOLParser#value}.
     * @param ctx the parse tree
     */
    void enterMethodExp(FOOLParser.MethodExpContext ctx);
    /**
     * Exit a parse tree produced by the {@code methodExp}
     * labeled alternative in {@link FOOLParser#value}.
     * @param ctx the parse tree
     */
    void exitMethodExp(FOOLParser.MethodExpContext ctx);
    /**
     * Enter a parse tree produced by the {@code newExp}
     * labeled alternative in {@link FOOLParser#value}.
     * @param ctx the parse tree
     */
    void enterNewExp(FOOLParser.NewExpContext ctx);
    /**
     * Exit a parse tree produced by the {@code newExp}
     * labeled alternative in {@link FOOLParser#value}.
     * @param ctx the parse tree
     */
    void exitNewExp(FOOLParser.NewExpContext ctx);
    /**
     * Enter a parse tree produced by {@link FOOLParser#var}.
     * @param ctx the parse tree
     */
    void enterVar(FOOLParser.VarContext ctx);
    /**
     * Exit a parse tree produced by {@link FOOLParser#var}.
     * @param ctx the parse tree
     */
    void exitVar(FOOLParser.VarContext ctx);
    /**
     * Enter a parse tree produced by the {@code varStmAssignment}
     * labeled alternative in {@link FOOLParser#stm}.
     * @param ctx the parse tree
     */
    void enterVarStmAssignment(FOOLParser.VarStmAssignmentContext ctx);
    /**
     * Exit a parse tree produced by the {@code varStmAssignment}
     * labeled alternative in {@link FOOLParser#stm}.
     * @param ctx the parse tree
     */
    void exitVarStmAssignment(FOOLParser.VarStmAssignmentContext ctx);
    /**
     * Enter a parse tree produced by the {@code ifStm}
     * labeled alternative in {@link FOOLParser#stm}.
     * @param ctx the parse tree
     */
    void enterIfStm(FOOLParser.IfStmContext ctx);
    /**
     * Exit a parse tree produced by the {@code ifStm}
     * labeled alternative in {@link FOOLParser#stm}.
     * @param ctx the parse tree
     */
    void exitIfStm(FOOLParser.IfStmContext ctx);
    /**
     * Enter a parse tree produced by the {@code methodStm}
     * labeled alternative in {@link FOOLParser#stm}.
     * @param ctx the parse tree
     */
    void enterMethodStm(FOOLParser.MethodStmContext ctx);
    /**
     * Exit a parse tree produced by the {@code methodStm}
     * labeled alternative in {@link FOOLParser#stm}.
     * @param ctx the parse tree
     */
    void exitMethodStm(FOOLParser.MethodStmContext ctx);
    /**
     * Enter a parse tree produced by the {@code printStm}
     * labeled alternative in {@link FOOLParser#stm}.
     * @param ctx the parse tree
     */
    void enterPrintStm(FOOLParser.PrintStmContext ctx);
    /**
     * Exit a parse tree produced by the {@code printStm}
     * labeled alternative in {@link FOOLParser#stm}.
     * @param ctx the parse tree
     */
    void exitPrintStm(FOOLParser.PrintStmContext ctx);
    /**
     * Enter a parse tree produced by the {@code funStm}
     * labeled alternative in {@link FOOLParser#stm}.
     * @param ctx the parse tree
     */
    void enterFunStm(FOOLParser.FunStmContext ctx);
    /**
     * Exit a parse tree produced by the {@code funStm}
     * labeled alternative in {@link FOOLParser#stm}.
     * @param ctx the parse tree
     */
    void exitFunStm(FOOLParser.FunStmContext ctx);
    /**
     * Enter a parse tree produced by {@link FOOLParser#stms}.
     * @param ctx the parse tree
     */
    void enterStms(FOOLParser.StmsContext ctx);
    /**
     * Exit a parse tree produced by {@link FOOLParser#stms}.
     * @param ctx the parse tree
     */
    void exitStms(FOOLParser.StmsContext ctx);
}
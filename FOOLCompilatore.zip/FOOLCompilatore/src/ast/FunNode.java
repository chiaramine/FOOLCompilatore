package ast;
import ast.types.ClassType;
import ast.types.FunType;
import ast.types.VoidType;
import org.antlr.v4.runtime.ParserRuleContext;
import util.Environment;
import util.Helpers;
import util.SymbolTableEntry;
import util.TypeCheckException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

public class FunNode implements Node {

	protected String name;
	protected Node type;

	protected ArrayList<Node> parList;
	protected ArrayList<Node> decList;
	protected ArrayList<Node> body;
	protected ParserRuleContext ctx;

	protected SymbolTableEntry funEntry;


	public FunNode (String name, Node type, ArrayList<Node> decList, ArrayList<Node> parList, ArrayList<Node> body, ParserRuleContext ctx) {
		this.ctx = ctx;
		this.name = name;
		this.type = type;
		this.decList = decList;
		this.parList = parList;
		this.body = body;
	}

	public SymbolTableEntry getSTEntry(){
		return this.funEntry;
	}

	public Node copyInstance() {
		ParserRuleContext ctx = new ParserRuleContext();
		ctx.copyFrom(this.ctx);
		ArrayList<Node> decCopy = new ArrayList<>(this.decList);
		for (Node n: this.decList)
			decCopy.add(n.copyInstance());
		ArrayList<Node> parCopy = new ArrayList<>(this.parList);
		for (Node n: this.parList)
			parCopy.add(n.copyInstance());
		ArrayList<Node> bodyCopy = new ArrayList<>(this.body);
		for (Node n: this.body)
			bodyCopy.add(n.copyInstance());
		FunNode copy = new FunNode(this.name, this.type.copyInstance(), decCopy, parCopy, bodyCopy, ctx);
		copy.funEntry = SymbolTableEntry.copyInstance(this.funEntry);
		return copy;
	}


	@Override
	public HashSet<String> checkSemantics(Environment env) {
		//create result list
		HashSet<String> res = new HashSet<>();

		HashMap<String, SymbolTableEntry> hm = env.getSymTable().get(env.getNestingLevel());
		int offset = env.decreaseOffset();

		if (type instanceof FunType && ((FunType)type).getReturnType() instanceof ClassType) {
			Node rt = ((FunType)type).getReturnType();
			ClassType curType = (ClassType)rt;
			SymbolTableEntry classEntry = env.getClassEntry(curType.getID());
			((FunType)type).updateReturnType(classEntry.getType());
		}

		SymbolTableEntry entry = new SymbolTableEntry(env.getNestingLevel(), offset, type);
		String funID = "Function$" + name;

		if (!env.getFunSecondCheck()) {
			if (hm.get(funID) != null)
				res.add("Function " + name + " already declared at line: " + ctx.start.getLine() + ":" + ctx.start.getCharPositionInLine() + "\n");
			else
				hm.put(funID, entry);
		}
		else {
			SymbolTableEntry existingEntry = hm.get(funID);
			existingEntry.setOffset(offset);
			this.funEntry = existingEntry;
		}

		env.pushScope();
		int currentOffset = env.getOffset();

		env.setOffset(1);
		for (Node par : parList) {
			VarNode arg = (VarNode) par;
			res.addAll(arg.checkSemantics(env));
		}
		env.setOffset(currentOffset);

		this.funEntry = entry;

		if (!decList.isEmpty()) env.setOffset(-2);

		if (env.getFunSecondCheck()) {
			for (Node dec : decList)
				res.addAll(dec.checkSemantics(env));

			for (Node b : body)
				res.addAll(b.checkSemantics(env));
		}

		env.popScope();

		return res;
	}

	public String toPrint(String s) {
		StringBuilder parlstr = new StringBuilder();
		StringBuilder declstr = new StringBuilder();

		if (parList != null && !parList.isEmpty())
			for (Node par : parList)
				parlstr.append("\n").append(par.toPrint(s + "\t\t"));

		if (decList != null && !decList.isEmpty()) {
			declstr.append("\n").append(s).append("\tFun Decs:");
			for (Node dec : decList)
				declstr.append("\n").append(dec.toPrint(s + "\t\t"));
		}

		return  s + "Fun Dec Node: " + name + " : " + //Fun Dec Node
				((this.funEntry != null) ? this.funEntry.getType().toPrint(s + "\t"): "") +
				parlstr.toString() +
				declstr.toString();
	}

	public Node typeCheck () throws Exception {

		for (Node p : parList) p.typeCheck();
		for (Node d : decList) d.typeCheck();
		for (Node b : body) b.typeCheck();

		// check if the type of the last stms or exp in body is subtype of the function return type
		if (!Helpers.subtypeOf(body.get(body.size()-1).typeCheck(), ((FunType)type).getReturnType()))
			throw new TypeCheckException("Function Return", ctx.start.getLine(), ctx.start.getCharPositionInLine());

		return ((FunType)type).getReturnType();
	}

	public String codeGeneration() {
		StringBuilder decAssembly = new StringBuilder();
		StringBuilder decPopAssembly = new StringBuilder();
		StringBuilder parPopAssembly = new StringBuilder();
		StringBuilder bodyAssembly = new StringBuilder();
		String funLabel = Helpers.newFuncLabel();

		FunType funcType = (FunType)type;
		String storeRetVal = funcType.getReturnType() instanceof VoidType ? "" : "srv\n";
		String loadRetVal = funcType.getReturnType() instanceof VoidType ? "" : "lrv\n";

		for (Node dec: decList) {
			decAssembly.append(dec.codeGeneration());
			decPopAssembly.append("pop\n");
		}

		for (Node par: parList)
			parPopAssembly.append("pop\n");

		for (Node n: body)
			bodyAssembly.append(n.codeGeneration());

		String funcCode = funLabel + ":\n" +
				"cfp\n" +
				"lra\n" +
				decAssembly.toString() +
				bodyAssembly.toString() +
				storeRetVal +
				decPopAssembly.toString() +
				"sra\n" +
				"pop\n" +
				parPopAssembly.toString() +
				"sfp\n" +
				loadRetVal +
				"lra\n" +
				"js\n";
		Helpers.appendFuncAssembly(funcCode);

		return "push " + funLabel + "\n";
	}

	public String getID() {
		return name;
	}

}
// Generated from /Users/chiaraminervino/Desktop/FOOLCompilatore/src/parser/SVM.g4 by ANTLR 4.8
        package parser;


import java.util.HashMap;

import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link SVMParser}.
 */
public interface SVMListener extends ParseTreeListener {
    /**
     * Enter a parse tree produced by {@link SVMParser#assembly}.
     * @param ctx the parse tree
     */
    void enterAssembly(SVMParser.AssemblyContext ctx);
    /**
     * Exit a parse tree produced by {@link SVMParser#assembly}.
     * @param ctx the parse tree
     */
    void exitAssembly(SVMParser.AssemblyContext ctx);
    /**
     * Enter a parse tree produced by {@link SVMParser#simpleCmd}.
     * @param ctx the parse tree
     */
    void enterSimpleCmd(SVMParser.SimpleCmdContext ctx);
    /**
     * Exit a parse tree produced by {@link SVMParser#simpleCmd}.
     * @param ctx the parse tree
     */
    void exitSimpleCmd(SVMParser.SimpleCmdContext ctx);
    /**
     * Enter a parse tree produced by {@link SVMParser#composedCmd}.
     * @param ctx the parse tree
     */
    void enterComposedCmd(SVMParser.ComposedCmdContext ctx);
    /**
     * Exit a parse tree produced by {@link SVMParser#composedCmd}.
     * @param ctx the parse tree
     */
    void exitComposedCmd(SVMParser.ComposedCmdContext ctx);
}
package ast;

import ast.types.*;
import org.antlr.v4.runtime.ParserRuleContext;
import util.*;
import java.util.HashSet;

public class IntNode implements Node {

    private int value;
    private ParserRuleContext ctx;

    /**
     *
     * Rappresenta i valori interi
     *
     * */
    public IntNode(int n, ParserRuleContext ctx) {
        value = n;
        this.ctx = ctx;
    }

    public Node copyInstance() {
        ParserRuleContext ctx = new ParserRuleContext();
        ctx.copyFrom(this.ctx);
        return new IntNode(this.value, ctx);
    }

    public String toPrint(String s) {
        return s + "Integer value: " + value;
    }

    public HashSet<String> checkSemantics(Environment env) {
        HashSet<String> res = new HashSet<>();

        if (value == Integer.MAX_VALUE)
            res.add("Integer value ±" + Integer.MAX_VALUE + " is reserved and can't be used at line " + ctx.start.getLine() + ":" + ctx.start.getCharPositionInLine());

        return res;
    }

    public Node typeCheck() {
        return new IntType();
    }

    public String codeGeneration() {
        return  "push " + value + "\n";
    }

    // Method to retrieve string identifier of an object
    // In nodes where identifier is not significant, null is returned
    public String getID() {
        return null;
    }
}

package util;

public class ExpiredMemoryException extends Exception  {

    public ExpiredMemoryException() {
        super("Expired memory", null, true, false);
    }

    public String toString() {
        return "Integer value excede memory: your math may be incorrect \n";
    }

    @Override
    public String getMessage() {
        return this.toString();
    }
}
